package com.example.itbangmodkradankanbanapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ItBangmodKradanKanbanApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(ItBangmodKradanKanbanApiApplication.class, args);
    }

}
