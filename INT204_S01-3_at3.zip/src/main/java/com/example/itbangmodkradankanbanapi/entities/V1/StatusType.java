package com.example.itbangmodkradankanbanapi.entities.V1;

public enum StatusType {
    TO_DO,
    DOING,
    NO_STATUS,
    DONE
}